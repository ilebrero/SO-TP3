#ifndef __srv_h__
#define __srv_h__

#include "tp3.h"

void servidor(int mi_cliente);

#endif
